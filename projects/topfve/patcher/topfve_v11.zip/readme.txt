                               Tales of Phantasia: Full Voice Edition
                                        English Translation
                                      v1.1 (August 15th, 2026)

====================================================================================================

- No ownership is claimed by Life Bottle Productions over Tales of Phantasia Full Voice Edition or
   the franchise from which it originates. Commercial use of this patch, including but not limited to
   reproduction, sale, etc. is strictly prohibited.

- This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
   Life Bottle Productions are not liable for damage incurred to the end-user, their OS, or their
   hardware while using this patch.
   
- Apply this patch only to a Japanese Tales of Phantasia Full Voice Edition UMD image in ISO format
   with the following specifications:
     Hashes: MD5  - 986193786969438311A41262AEAD541A
             SHA1 - DBDD4BD45DEA91511053B805704DD8CF3755B3C5


   Table of Contents

To reach a given section, Ctrl+F the text fragments in brackets.


Preface ............. [RM01]
Patch Notes ......... [RM02]
Changelog ........... [RM03]
FAQ ................. [RM04]
Credits ............. [RM05]

====================================================================================================

   [RM01] Preface
   
  mziab

Bet you weren't expecting this, huh? Well, neither did I. But when Ethanol suddenly announced that
he basically ported over ALL of our assembly mods to FVE in a space of two days, I figured there was
no reason NOT to pursue this further... so I did. The code and assets from both versions are so
amazingly similar, they might as well be carbon copies. Aside from some different tags and
tutorials, and of course not having any Rody scenes, the text was identical and I was able to
migrate the script over in minutes. Tweaking the tools and porting over the menu text and other
translated assets took a few more days. Some of the graphics were different from X and some extra
programming needed to be done, but I'll just say this: at the end of February we had a mostly
working build - translated text, graphics, skit subtitles and QoL changes. Yes, you read that right.
We ported EVERYTHING. All that was left was squashing a few annoying bugs and testing the entire
thing. Due to being pre-occupied with other things at the time, I had to take a break from the
project, but in early May I was able to patch all known issues and Kevan played through the entire
game. Since we were busy with the upcoming v1.2 patch for X, it was decided that we might as well
get some more testing in and this is where Gate rose to occasion and gave the game a fair shake. And
this brings us to today. Those who enjoy a more traditional battle system with spell pause and don't
want a certain skin-clad character in their game, can now enjoy playing in English as well. Enjoy,
everyone!

====================================================================================================

   [RM02] Patch Notes

The main patch features the following quality-of-life improvements over the base game:

- Added a skit prompt on the world map
- Added a new Red Lantern location in the Airfread quest
- Restored the original ending credits song
- Removed the Dark element from Suzu's Chizakura weapon
- Made the stealth section of Alvanista Castle less punishing
- Added a toggle for turning Battle Subs on/off
- Added a toggle for turning enhanced Holy Bottles on/off (enhanced bottles stop encounters fully
  for their duration, as in modern games)
- Monster Book is now alphabetically sorted and starts at the first entry
- Added all Dhaos forms to the Monster Book
- The Sorcerer's Ring doesn't need to be equipped to be able to shoot fire
- Curio's Mirror, Scout Orb and Combo Counter now carry over in New Game+ if you select the option
  to carry over items
- Restored Rhea's Super Deformed sprite from ToP GBA
- Monster Book sprites now use the actual enemy graphics
- Ishrantu's Monster Book entry now correctly lists the elemental weakness as Earth
- One censored skit about drinking is now restored
- Fixed coords for two hotspots which were misplaced in the original game (bookshelves in the back
  of the item shop in the Elven Settlement and Arche's crying animation during a cutscene)
- Fixed HP/TP restore on level-up not taking accessories into account
- Added a Technical Ring to the starting equipment

Since some of these affect the gameplay, we have provided a "vanilla" patch for those preferring to
forgo gameplay-related improvements and have the original experience.

The text is based on the Phantasian Productions localization and as such we have decided not to
disturb it if we didn't need to out of respect for their work. Obvious typos, punctuation and
grammatical mistakes have been corrected and some incidental lines have been trimmed to match the
voice-over better. The Quiche recipe name has been reverted to the original Chawanmushi and some
tutorial text has been tweaked. Apart from that, this patch keeps to the conventions established by
Phantasian Productions.

====================================================================================================

   [RM03] Changelog

v1.1 (August 15th, 2026)
- Fixed Combo Counter toggle accidentally toggling enhanced Holy Bottles
- Fixed phantom subtitles appearing for a split-second during some voiced events
- Replaced monster book sprites with actual enemy sprites (fixed repacking issue in v1.0)

v1.0 (June 27th, 2026)
- Initial release

====================================================================================================

====================================================================================================

   [RM04] Frequently Asked Questions

Q: Will this work with Tales of Phantasia Cross Edition?
A: No, this patch is only compatible with Tales of Phantasia Full Voice Edition.

Q: I'm getting graphical glitches on PPSSPP, help! What do I do?
A: Please upgrade your emulator. Earlier versions are known to have graphical issues with this game
   in particular. For more information, refer to the included "How to fix the graphics.txt" file.

Q: Why is the opening FMV choppy when playing on my Vita?
A: The game has performance problems in FMVs when using Adrenaline filters. Make sure that filters
   are turned off or else you will suffer from FMV stuttering.

====================================================================================================

   [RM05] Credits

Project Managers
- mziab
- Pegi

Project Coordinator
- Dragonbleapiece

Lead Programmer
- mziab

Programmers
- Ethanol
- Julian

Main Translator
- Goodguy3

Translators
- Mine
- SymphoniaLauren
- Pegi
- mziab

Lead Editors
- Dragonbleapiece
- mziab

Editors
- Kevan
- gatordski
- yoh
- Khayyaam
- FlamePurge

Graphic Artists
- Amarant
- FlamePurge
- WilliamTBOG

Pre-production Information Gathering
- Kevan

Lead Localization QA
- Dragonbleapiece

Lead Functional QA
- DobleC

QA Testers
- Kevan
- flynnforthewin
- Nanika
- getterdrill
- Torasouls
- FlamePurge
- dotaxis
- ryuza
- Trixarian
- Negi
- bobwhite
- edgarfigaro
- gatordski
- Explorer
- Gate

Translation Feature Consultation
- FlamePurge

Original PSX Script and Translated Assets
- Phantasian Productions
