Please use TB_InnoR_Demo_v1.0.xdelta if you are patching the demo with the full twin brave game
If you are using the dedicated japanese Innocence R demo then please use TB_InnoR_Demo_Demo_v1.0.xdelta